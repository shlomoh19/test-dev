module.exports = {
    host: "localhost",
    user: "root",
    password: "",
    database: "node_api"
  };